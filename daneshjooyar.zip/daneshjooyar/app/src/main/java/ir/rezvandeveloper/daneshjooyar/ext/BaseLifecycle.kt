package ir.rezvandeveloper.daneshjooyar.ext

interface BaseLifecycle {

    fun onCreate()

    fun onStart(){}

}