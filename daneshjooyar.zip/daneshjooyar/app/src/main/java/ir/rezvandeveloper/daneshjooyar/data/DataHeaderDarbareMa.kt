package ir.rezvandeveloper.daneshjooyar.data

import android.graphics.drawable.Drawable

data class DataHeaderDarbareMa(
    val count :String,
    val name:String,
    val img: Drawable
)
