package ir.rezvandeveloper.daneshjooyar.data

import android.graphics.drawable.Drawable

data class DataHeaderRecyclerView(
    var id: Int,
    var name: String,
    var img: Drawable
)
