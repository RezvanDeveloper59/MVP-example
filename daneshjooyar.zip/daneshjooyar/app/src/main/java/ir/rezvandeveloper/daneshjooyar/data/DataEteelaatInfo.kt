package ir.rezvandeveloper.daneshjooyar.data

import android.graphics.drawable.Drawable

data class DataEteelaatInfo(
    var count: String,
    var name: String,
    val img: Drawable
)
