package ir.rezvandeveloper.daneshjooyar.dp.model

data class Pishraft(
    var id: Int,
    var name: String,
    var darsad_pishraft: Int
)